
#include <stdio.h>
#include <string.h>

int main(int argc,char* argv[]){
    int var1,var2,i,isDebug=0,modif=32 ,isEnc = 0;
    int counter=0;
    FILE* input = stdin;
    for(i = 1;i < argc; i++){
        if(strcmp(argv[i],"-D") == 0){
            if(strlen(argv[i]) == 2){
                puts(argv[i]);
                isDebug = 1;
            }
        }
        char arg[2];
        arg[0] = argv[i][0];
        arg[1] = argv[i][1];
        if(strcmp(arg,"-e") == 0 && strlen(argv[i]) == 3){
            isEnc = 1;
            if(argv[i][2]-60 < 0)
                modif = -(argv[i][2]-'0');
            else
                modif = -(argv[i][2]-'7');
        }
        if(strcmp(arg,"+e") == 0){
            if(strlen(argv[i]) == 3){
                isEnc = 1;
                if(argv[i][2]-60 < 0)
                    modif = argv[i][2]-'0';
                else
                    modif = argv[i][2]-'7';
            }
        }
        if(strcmp(arg,"-i") == 0 && strlen(argv[i]) > 2){
            if((input = fopen(argv[i]+2, "r")) == NULL)
                fprintf(stderr, "File doesn't exists");
        }
        
    }
    while(1){
        var1 = getc(input);
        var2 = var1;
        if(var1 == EOF){
            fprintf(stdout, "\n");
            fprintf(stderr,"\nthe number of letters: %d\n\n",counter);//printing how many letters changed
            counter = 0;
            break;
        }
        if(isEnc==1 & var1 != '\n'){
            var2=var1+modif;
            counter++;
        } else if(var1 >= 'A' && var1<= 'Z' & var1 != '\n'){
            var2 = var1 + 32;
            counter++;
        }
        if(var1 != '\n'){ //if the input wasnt new line
            fprintf(stderr, "%d\t%d\n",var1,var2);  //printing the value of the 2 variables in asci table  
            fputc(var2,stdout); //
        }
        else{
            if(isDebug){ //if we have debugged
            fprintf(stderr,"\nthe number of letters: %d\n\n",counter);//printing how many letters changed
            counter=0;
            }
            fputc(var1,stdout);
        }
    }
    fclose(input);
    return 0;
}